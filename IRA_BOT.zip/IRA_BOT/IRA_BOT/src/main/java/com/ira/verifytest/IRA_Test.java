package com.ira.verifytest;

import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ira.functionality.IRA_functionality;
import com.ira.utility.BaseClassIRA;

public class IRA_Test extends BaseClassIRA {

	public static WebDriver chromeDriver;
	public static Wait<WebDriver> wait;
	IRA_functionality ira_Fun;

	@BeforeClass
	public void setUp() throws MalformedURLException, InterruptedException {
		chromeDriver = getDriver();
		BaseClassIRA.initializePageFactory(chromeDriver);
		wait = BaseClassIRA.wait;
		ira_Fun = new IRA_functionality(chromeDriver, wait);
	}

	@Test(priority = 1, enabled = true, description = "Verify that Test agent - IRA page is loaded ")
	public void verifyTitle() {

		System.out.println("IRA page test...");
		Assert.assertTrue(ira_Fun.getPageTitle(), "IRA page - unable to load Test agent - IRA page");
		System.out.println("Test Case PASS : verify Test agent - IRA page is loaded ");
		System.out.println("");
	}

	@Test(priority = 2, enabled = true, description = "Verify that user can click on IRA Bot Notification")
	public void verifyClickIRA_Bot() {

		System.out.println("IRA page test...");
		Assert.assertTrue(ira_Fun.getClickBot(), "IRA page - unable to click on IRA Bot Notification");
		System.out.println("Test Case PASS : Verify that user can click on IRA Bot Notification");
		System.out.println("");
	}

	@Test(priority = 3, enabled = true, description = "Verify that user can download motor policy")
	public void verifyDownloadMotorPolicy() {

		System.out.println("IRA page test...");
		Assert.assertTrue(ira_Fun.getDownloadMP(),
				"IRA page - unable to download motor policy and navigate to policy page");
		System.out.println("Test Case PASS : Verify that user can download motor policy");
		System.out.println("");
	}

	@Test(priority = 4, enabled = true, description = "Verify that user sends text as test bot and fills the form")
	public void verifyTestBot() {

		System.out.println("IRA page test...");
		Assert.assertTrue(ira_Fun.getTestBot(),
				"IRA page - unable to send text as test bot and unable to fills the form");
		System.out.println("Test Case PASS : Verify that user sends text as test bot and fills the form");
		System.out.println("");
	}

	@Test(priority = 5, enabled = true, description = "Verify that user sends text as new test and clicks google, call fucntions and close the tab")
	public void verifyNewTest() {

		System.out.println("IRA page test...");
		Assert.assertTrue(ira_Fun.getNewTest(),
				"IRA page - unable to send text as new test and clicks google, call fucntions and close the tab");
		System.out.println(
				"Test Case PASS : Verify that user sends text as new test and clicks google, call fucntions and close the tab");
		System.out.println("");
	}
}
