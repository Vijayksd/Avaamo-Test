package com.ira.PageFactory;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class IRA_PF {

	@FindBy(xpath = "//small[@class='avm-welcome-notification-message']")
	public static WebElement bot;

	@FindBy(xpath = "//div[@class='default_card_description']")
	public static WebElement text_description;

	@FindBy(xpath = "//a[@class='get-started-link']")
	public static WebElement btn_getStarted;

	@FindBy(xpath = "//div[@class='welcome-message']")
	public static WebElement msg_welcome;

	@FindBy(tagName = "iframe")
	public static List<WebElement> tag_iFrame;

	@FindBy(xpath = "//a[@actionname='Start Over']")
	public static WebElement btn_Startover;

	@FindBy(xpath = "//textarea[@name='message']")
	public static WebElement sendMsg;

	@FindBy(xpath = "//p[@class='desc text-content ']")
	public static List<WebElement> respMsg;

	@FindBy(xpath = "//div[@title='Switch to bot menu']")
	public static WebElement switchBotMenu;

	@FindBy(linkText = "Download Motor Policy")
	public static WebElement dwnldMotorPolicy;

	@FindBy(linkText = "Download")
	public static WebElement download_MP;

	@FindBy(xpath = "//input[@class='textbox']")
	public static WebElement tb_fullname;

	@FindBy(xpath = "//textarea[@class='textbox']")
	public static WebElement ta_address;

	@FindBy(xpath = "//span[text()='Male']")
	public static WebElement chkbx_Male;

	@FindBy(xpath = "//input[@class='textbox picklist-textbox']")
	public static WebElement select_policy;

	@FindBy(xpath = "//ul[@class='list picklist']")
	public static List<WebElement> ul_Plists;

	@FindBy(xpath = "//span[@class='star-cb-group']//label[1]")
	public static WebElement stars5;

	@FindBy(xpath = "//button[@class='btn default_card_submit']")
	public static WebElement btn_Submit;

	@FindBy(xpath = "//button[@class='btn default_card_submit success']")
	public static WebElement btn_submitsuccess;

	@FindBy(xpath = "//a[text()='Google']")
	public static WebElement link_google;

	@FindBy(xpath = "//button[@class='close']")
	public static WebElement btn_close;

	@FindBy(xpath = "//a[text()='Call']")
	public static WebElement link_call;

}
