package com.ira.functionality;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;

import com.ira.PageFactory.IRA_PF;
import com.ira.utility.BaseClassIRA;

public class IRA_functionality {

	public static Wait<WebDriver> wait;
	public static WebDriver chromeDriver;
	public Actions action;
	public int count;
	boolean bool_countMatching;
	boolean bool_resultLbl;
	boolean bool_votesTab;
	boolean bool_title;
	boolean bool_votesandAnswers;
	JavascriptExecutor js;
	boolean bool_greetMsg;
	boolean bool_motorPolicyURL;
	boolean bool_submitSuccess;
	boolean bool_popups;

	public IRA_functionality(WebDriver chromeDriver, Wait<WebDriver> wait) {
		IRA_functionality.chromeDriver = chromeDriver;
		IRA_functionality.wait = wait;
		js = BaseClassIRA.javascriptExecutor;
		action = new Actions(chromeDriver);
	}

	public boolean getPageTitle() {

		String pageTitle = chromeDriver.getTitle();
		if (pageTitle.contains("Test agent - IRA"))
			bool_title = true;

		return bool_title;

	}

	public boolean getClickBot() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(IRA_PF.bot)).click();
			String welcome_msg = wait.until(ExpectedConditions.elementToBeClickable(IRA_PF.msg_welcome)).getText();
			System.out.println("Welcome Message:" + welcome_msg);
			IRA_PF.btn_getStarted.click();
			chromeDriver.switchTo().frame("avaamoIframe");
			Thread.sleep(2000);
			js.executeScript("arguments[0].scrollIntoView(true);", IRA_PF.text_description);
			String text = wait.until(ExpectedConditions.elementToBeClickable(IRA_PF.text_description)).getText();
			System.out.println("Description sent by IRA Bot: " + text);
			IRA_PF.btn_Startover.click();
			IRA_PF.sendMsg.sendKeys("Hi, How are you?");
			action = new Actions(chromeDriver);
			action.sendKeys(Keys.ENTER).build().perform();
			System.out.println("User Sent: "+"Hi, How are you?"); 
			Thread.sleep(2000);
			List<WebElement> resp_list = IRA_PF.respMsg;
			int k = resp_list.size();
			String resp_text = "";
			for (int i = 0; i < k; i++) {
				js.executeScript("arguments[0].scrollIntoView(true);", resp_list.get(i));
				resp_text = resp_list.get(i).getText();
				if(i == k-1)
				System.out.println("Response message sent by IRA Bot: " + resp_text);

			}
			Thread.sleep(2000);
			if (resp_text.equalsIgnoreCase("Here is an option I can help with. Can you confirm?")
					|| resp_text.equalsIgnoreCase(
							"Here is an option I can help with, based on what I understood. Can you confirm?"))
				bool_greetMsg = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("exception in getClickBot" + e);
		}

		return bool_greetMsg;

	}

	public boolean getDownloadMP() {
		try {

			IRA_PF.switchBotMenu.click();
			IRA_PF.btn_Startover.click();
			wait.until(ExpectedConditions.elementToBeClickable(IRA_PF.dwnldMotorPolicy)).click();
			wait.until(ExpectedConditions.elementToBeClickable(IRA_PF.download_MP)).click();
			Thread.sleep(2000);
			Set<String> urls = chromeDriver.getWindowHandles();
			ArrayList<String> aList = new ArrayList<String>(urls.size());

			// aList.add(x);
			for (String str : urls) {
				aList.add(str);
				chromeDriver.switchTo().window(str);
				String urlsOfWindows = chromeDriver.getCurrentUrl();
				// System.out.println("urlsOfWindows:"+urlsOfWindows);
			}

			if (chromeDriver.getCurrentUrl()
					.equalsIgnoreCase("https://www.iffcotokio.co.in/portal/private-car/policy-download")) {
				bool_motorPolicyURL = true;
				for (int i = 0; i < aList.size(); i++) {
					chromeDriver.switchTo().window(aList.get(i));
					break;
				}

			}

		} catch (Exception e) {
			System.out.println("exception in getDownloadMP" + e);
		}
		return bool_motorPolicyURL;
	}

	public boolean getTestBot() {
		try {

			Thread.sleep(2000);
			chromeDriver.switchTo().frame("avaamoIframe");
			IRA_PF.switchBotMenu.click();
			IRA_PF.btn_Startover.click();
			IRA_PF.sendMsg.sendKeys("Test Bot");
			// action = new Actions(chromeDriver);
			action.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(2000);
			js.executeScript("arguments[0].scrollIntoView(true);", IRA_PF.tb_fullname);
			IRA_PF.tb_fullname.sendKeys("Vijaykumar Dinnimani");
			IRA_PF.ta_address.sendKeys("Singasandra, Bangalore");
			IRA_PF.chkbx_Male.click();
			IRA_PF.select_policy.click();
			List<WebElement> ele = IRA_PF.ul_Plists;
			for (WebElement wb : ele) {
				Thread.sleep(1000);
				wb.click();
				break;
			}
			IRA_PF.stars5.click();
			IRA_PF.btn_Submit.click();
			Thread.sleep(2000);
			js.executeScript("arguments[0].scrollIntoView(true);", IRA_PF.btn_submitsuccess);
			String suc = IRA_PF.btn_submitsuccess.getText();
			//System.out.println("suc:" + suc);
			if (suc.equalsIgnoreCase("Submitted Successfully"))
				bool_submitSuccess = true;

		} catch (Exception e) {
			System.out.println("exception in getTestBot" + e);
		}
		return bool_submitSuccess;
	}

	public boolean getNewTest() {
		try {

			IRA_PF.switchBotMenu.click();
			IRA_PF.btn_Startover.click();
			IRA_PF.sendMsg.sendKeys("New Test");
			action.sendKeys(Keys.ENTER).build().perform();
			Thread.sleep(2000);
			IRA_PF.link_google.click();
			IRA_PF.btn_close.click();
			IRA_PF.link_call.click();
			Thread.sleep(2000);
			Set<String> urls_1 = chromeDriver.getWindowHandles();
			ArrayList<String> aList_1 = new ArrayList<String>(urls_1);
			chromeDriver.switchTo().window(aList_1.get(2));
			chromeDriver.close();
			Set<String> urls_2 = chromeDriver.getWindowHandles();
			ArrayList<String> aList_2 = new ArrayList<String>(urls_2);
			int listofTabs = aList_2.size();
			if (listofTabs == 2)
				bool_popups = true;
		} catch (Exception e) {
			System.out.println("exception in getTestBot" + e);
		}
		return bool_popups;
	}
}
