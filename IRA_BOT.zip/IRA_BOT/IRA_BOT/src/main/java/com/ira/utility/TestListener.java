package com.ira.utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

public class TestListener implements ITestListener {

	public ExtentTest test1 = ExtentTestManager.test;

	static Date date = new Date();
	static SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
	static String strDate = formatter.format(date);
	public ExtentReports extent;
	// public ExtentTest testLogger;

	ITestResult result;

	public void onStart(ITestContext context) {
		System.out.println("*** Test Suite " + context.getName() + " started ***");
	}

	public void onFinish(ITestContext context) {
		System.out.println(("*** Test Suite " + context.getName() + " ending ***"));
		ExtentTestManager.endTest();
		ExtentManager.getInstance().flush();
	}

	public void onTestStart(ITestResult result) {
		System.out.println(("*** Running test method " + result.getMethod().getMethodName() + "..."));
		ExtentTestManager.startTest(result.getMethod().getMethodName(), result.getMethod().getDescription());
	}

	public void onTestSuccess(ITestResult result) {
		String[] methodName = result.getMethod().getMethodName().split("verify");
		// String descName = result.getMethod().getDescription();
		System.out.println("*** Executed " + methodName[1] + " test successfully...");
		// System.out.println("*** Executed " + descName + " test successfully...");
		System.out.println("");
		ExtentTestManager.getTest().log(Status.PASS, "Test passed");
	}

	public void onTestFailure(ITestResult result) {
		String[] methodName = result.getMethod().getMethodName().split("verify");
		System.out.println("*** Test execution " + methodName[1] + " failed...");
		System.out.println("");

		String exceptionMessage = Arrays.toString(result.getThrowable().getStackTrace());
		String path = takeScreenshot(result.getMethod().getMethodName());
		try {

			ExtentTestManager.test.fail("<details><summary><b><font color=red>Exception occured, click to see details:"
					+ "</font></b></summary>" + exceptionMessage.replaceAll(",", "<br>") + "</details> \n");
			MediaEntityBuilder.createScreenCaptureFromPath(path).build();
			// System.out.println("extent reprot"+ExtentTestManager.test);
			ExtentTestManager.test.fail("<b><font color=red>" + "Screenshot of failure" + "</font></b>",
					MediaEntityBuilder.createScreenCaptureFromPath(path).build());

		} catch (IOException e) {
			ExtentTestManager.test.fail("Test failed, cannot attach screenshot");
		}

		String logText = "<b>Test Method: " + methodName + " Failed</b>";
		ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");

	}

	public void onTestSkipped(ITestResult result) {
		String[] methodName = result.getMethod().getMethodName().split("verify");
		System.out.println("*** Test " + methodName[1] + " skipped...");
		System.out.println("");
		ExtentTestManager.getTest().log(Status.SKIP, "Test Skipped");
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		String[] methodName = result.getMethod().getMethodName().split("verify");
		System.out.println("*** Test failed but within percentage % " + methodName[1]);
	}

	public String takeScreenshot(String methodName) {

		String fileName = getScreenshotName(methodName);
		String directory = System.getProperty("user.dir") + "\\screenshots\\";
		new File(directory).mkdir();
		String path = directory + fileName;

		try {
			File screenshot = ((TakesScreenshot) BaseClassIRA.chromeDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshot, new File(path));
			System.out.println("******************************************************");
			System.out.println("Screenshot stored at " + path);
			System.out.println("******************************************************");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return path;
	}

	public static String getScreenshotName(String methodName) {

		// System.out.println("getScreenshotName:"+methodName);
		String fileName = methodName + "_" + strDate + ".png";
		// System.out.println("fileName:"+fileName);
		return fileName;
	}

}
