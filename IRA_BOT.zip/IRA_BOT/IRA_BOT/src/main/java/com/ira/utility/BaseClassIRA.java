package com.ira.utility;

import java.net.MalformedURLException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentTest;
import com.ira.PageFactory.IRA_PF;

public class BaseClassIRA {
	public static WebDriver chromeDriver;
	private static String exePath = "C:\\Users\\User\\Tenant_Admin\\Tenant Admin\\";
	public static Wait<WebDriver> wait;
	public static JavascriptExecutor javascriptExecutor;
	public static XSSFSheet ExcelWSheet;
	public static XSSFWorkbook ExcelWBook;
	public static XSSFCell Cell;
	public static XSSFRow Row;
	private static String browserType;
	private static String appURL;
	public static String browserName;
	public static String browserVersion;
	public static String platformName;
	public String screenShotLocation;
	public static ExtentTest extentTest;
	static Date date = new Date(0);
	static SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
	static String strDate = formatter.format(date);

	@Parameters({ "browserType", "appURL" })
	public WebDriver getDriver() {
		return chromeDriver;
	}

	private void setDriver(String browserType, String appURL) {
		switch (browserType) {
		case "chrome":
			chromeDriver = initChromeDriver(appURL);
			break;
		}
	}

	@SuppressWarnings("deprecation")
	private static WebDriver initChromeDriver(String appURL) {
		System.out.println("Launching google chrome with new profile..");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver", exePath + "chromedriver.exe");
		chromeDriver = new ChromeDriver(options);
		// options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
		chromeDriver.manage().window().maximize();
		wait = new FluentWait<WebDriver>(chromeDriver).withTimeout(Duration.ofSeconds(20))
				.pollingEvery(Duration.ofSeconds(5)).ignoring(Exception.class);

		/* wait = WebDriverWait(chromeDriver, 20); */
		javascriptExecutor = (JavascriptExecutor) chromeDriver;
		chromeDriver.navigate().to(appURL);

		Capabilities caps = ((RemoteWebDriver) chromeDriver).getCapabilities();
		// System.out.println(caps.getBrowserName());
		browserName = caps.getBrowserName();
		// System.out.println(caps.getVersion());
		browserVersion = caps.getVersion();
		// System.out.println(caps.getPlatform());
		platformName = caps.getPlatform().toString();

		return chromeDriver;
	}

	@Parameters({ "browserType", "appURL" })
	@BeforeClass
	public void initializeTestBaseSetup(String browserType, String appURL) {
		try {
			setDriver(browserType, appURL);

		} catch (Exception e) {
			System.out.println("Error....." + e.getStackTrace());
		}
	}

	public static void initializePageFactory(WebDriver chromeDriver)
			throws MalformedURLException, InterruptedException {
		// This initElements method will create all WebElements
		PageFactory.initElements(chromeDriver, IRA_PF.class);
	}

	@AfterClass
	public void closeBrowser() {
		chromeDriver.quit();
	}
}