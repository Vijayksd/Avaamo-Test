package com.ira.utility;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {

	public static ExtentReports extent;
	static Date date = new Date();
	static SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
	static String strDate = formatter.format(date);

	private static String fileName = "Test-Automation-Report" + strDate;

	private static String reportFileName = fileName + ".html";
	private static String fileSeperator = System.getProperty("file.separator");
	public static String reportFilepath = System.getProperty("user.dir") + fileSeperator + "TestReports";
	private static String reportFileLocation = reportFilepath + fileSeperator + reportFileName;

	public static ExtentReports getInstance() {
		if (extent == null)
			createInstance();
		return extent;
	}

	// Create an extent report instance
	public static ExtentReports createInstance() {

		System.out.println("file path:" + reportFilepath);
		String fileName = getReportPath(reportFilepath);

		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setDocumentTitle(reportFileName);
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setReportName(reportFileName);
		htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");

		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		// Set environment details
		// extent.setSystemInfo("OS", "Windows 10");
		extent.setSystemInfo("Browser Name", BaseClassIRA.browserName);
		extent.setSystemInfo("Browser Version", BaseClassIRA.browserVersion);
		extent.setSystemInfo("Browser Platform", BaseClassIRA.platformName);
		extent.setSystemInfo("AUTHOR", "Vijaykumar Dinnimani");
		// extent.setSystemInfo("Build", "Dev");

		return extent;
	}

	// Create the report path
	private static String getReportPath(String path) {
		File testDirectory = new File(path);
		if (!testDirectory.exists()) {
			if (testDirectory.mkdir()) {
				System.out.println("Directory: " + path + " is created!");
				return reportFileLocation;
			} else {
				System.out.println("Failed to create directory: " + path);
				return System.getProperty("user.dir");
			}
		} else {
			System.out.println("Directory already exists: " + path);
		}
		return reportFileLocation;
	}

}
